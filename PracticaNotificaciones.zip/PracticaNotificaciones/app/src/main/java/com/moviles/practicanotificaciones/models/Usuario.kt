package com.moviles.practicanotificaciones.models

class Usuario(
    var idUsuario: Int,
    var notification_id: String
)