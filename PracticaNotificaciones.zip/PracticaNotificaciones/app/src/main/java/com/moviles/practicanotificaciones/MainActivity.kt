package com.moviles.practicanotificaciones

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.moviles.practicanotificaciones.models.Respuesta
import com.moviles.practicanotificaciones.models.Usuario
import com.moviles.practicanotificaciones.repositories.ChatRepository

class MainActivity : AppCompatActivity(), ChatRepository.LogInListener {

    private lateinit var txtIdUser: TextView
    private lateinit var lblIdUser: EditText
    private val idUsuario = 18


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        txtIdUser = findViewById(R.id.txtIdUser)
        lblIdUser = findViewById(R.id.lblUserId)

        setupFireBase()
    }

    private fun setupFireBase() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener(OnCompleteListener { task ->
            if (!task.isSuccessful) {
                Log.w("TOKEN", "Fetching FCM registration token failed", task.exception)
                return@OnCompleteListener
            }

            // Get new FCM registration token
            val token = task.result as String
            val usuario = Usuario(idUsuario, token)
            ChatRepository.iniciarSesion(usuario, this)
            // Log and toast
            Log.d("TOKEN", token)
            //Toast.makeText(baseContext, token, Toast.LENGTH_SHORT).show()
        })
    }

    override fun onUsuarioSuccess(respuesta: Respuesta?) {
        val intent = Intent(this, ChatActivity::class.java)
        intent.putExtra("idUsuario", idUsuario)
        startActivity(intent)
    }

    override fun onUsuarioFailure(t: Throwable) {
        Toast.makeText(this, "Falla", Toast.LENGTH_SHORT).show()
    }
}